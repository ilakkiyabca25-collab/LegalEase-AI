import html
import os
import sys
from pathlib import Path
from datetime import date

import requests
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")

API_URL = os.getenv("LEGAL_EASE_API_URL", "http://127.0.0.1:8000")

st.markdown("""
<style>
.main-title { text-align:center; font-size:2.4rem; font-weight:800; margin-bottom:0.1rem; }
.subtitle { text-align:center; color:#64748b; margin-bottom:1.5rem; }
.preview { background:#111827; color:#f8fafc; border-radius:14px; padding:24px; max-height:600px; overflow:auto; line-height:1.65; }
.preview h3 { color:#93c5fd; margin-top:1.1rem; }
.preview p { margin:0.35rem 0; }
.spacer { height:0.4rem; }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-title">⚖️ LegalEase</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">AI-powered legal document drafting assistant</div>', unsafe_allow_html=True)
st.info("LegalEase creates drafts from your supplied information. Review any generated document with a qualified legal professional before signing or relying on it.")

with st.form("document_form"):
    col1, col2 = st.columns(2)
    with col1:
        document_type = st.selectbox("Document Type", ["Employment Contract", "Non-Disclosure Agreement", "Lease Agreement", "Service Agreement", "Freelance Work Contract", "Employment Offer Letter", "Custom Agreement"])
        if document_type == "Custom Agreement":
            document_type = st.text_input("Custom document type", placeholder="e.g. Partnership Agreement")
        parties = st.text_area("Parties Involved", placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)", height=120)
    with col2:
        effective_date = st.date_input("Effective Date", value=date.today())
        branding_name = st.text_input("Brand / Company Name", value="LegalEase")
        terms = st.text_area("Terms & Conditions", placeholder="Payment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice", height=120)
    submitted = st.form_submit_button("Generate Document", type="primary", use_container_width=True)

if submitted:
    if not document_type or not parties or not terms:
        st.error("Please complete the document type, parties, and terms.")
    else:
        payload = {"document_type": document_type, "parties": parties, "terms": terms, "effective_date": effective_date.isoformat(), "branding_name": branding_name}
        try:
            with st.spinner("Generating your legal draft..."):
                response = requests.post(f"{API_URL}/generate", json=payload, timeout=120)
            if response.ok:
                data = response.json()
                st.session_state["document"] = data["content"]
                st.session_state["document_type"] = data["document_type"]
                st.session_state["branding_name"] = branding_name
                st.success("Document generated successfully.")
            else:
                detail = response.json().get("detail", response.text)
                st.error(f"Backend error: {detail}")
        except requests.RequestException as exc:
            st.error(f"Could not reach the FastAPI backend at {API_URL}. Start the backend first. Details: {exc}")

if "document" in st.session_state:
    st.divider()
    st.subheader("Document Preview")
    edited = st.toggle("Edit Document")
    if edited:
        st.session_state["document"] = st.text_area("Edit generated document", st.session_state["document"], height=600)
    else:
        safe = html.escape(st.session_state["document"])
        # Preserve readable line breaks while keeping HTML escaped.
        rendered = safe.replace("\n", "<br>")
        st.markdown(f'<div class="preview">{rendered}</div>', unsafe_allow_html=True)

    text_bytes = st.session_state["document"].encode("utf-8")
    st.download_button("Download TXT", text_bytes, file_name="legalease_document.txt", mime="text/plain")

    try:
        from backend.services.formatters import format_docx, format_pdf
        docx_bytes = format_docx(st.session_state["document"], st.session_state["document_type"], st.session_state["branding_name"])
        pdf_bytes = format_pdf(st.session_state["document"], st.session_state["document_type"], st.session_state["branding_name"])
        c1, c2 = st.columns(2)
        with c1:
            st.download_button("Download DOCX", docx_bytes, file_name="legalease_document.docx", mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document", use_container_width=True)
        with c2:
            st.download_button("Download PDF", pdf_bytes, file_name="legalease_document.pdf", mime="application/pdf", use_container_width=True)
    except Exception as exc:
        st.error(f"Export error: {exc}")

st.caption(f"Backend: {API_URL}")
