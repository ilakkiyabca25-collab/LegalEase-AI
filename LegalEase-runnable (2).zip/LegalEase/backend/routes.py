from fastapi import APIRouter, HTTPException

from backend.ai_core.gemini_generator import GeminiDocumentGenerator
from backend.config import get_settings
from backend.schemas import DocumentRequest, DocumentResponse

router = APIRouter()
settings = get_settings()
generator = GeminiDocumentGenerator(settings)

@router.post("/generate", response_model=DocumentResponse)
def generate_document(request: DocumentRequest):
    combined = len(request.parties) + len(request.terms)
    if combined > settings.max_input_chars:
        raise HTTPException(status_code=413, detail="Input is too large for this application.")
    try:
        if settings.use_mock_ai:
            content = generator.mock_document(request.document_type, request.parties, request.terms, request.effective_date)
            return DocumentResponse(document_type=request.document_type, content=content, model="mock", mock=True)
        content = generator.generate_document(request.document_type, request.parties, request.terms, request.effective_date)
        return DocumentResponse(document_type=request.document_type, content=content, model=settings.gemini_model, mock=False)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
