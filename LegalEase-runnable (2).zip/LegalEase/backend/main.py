from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.config import get_settings
from backend.routes import router

settings = get_settings()
app = FastAPI(title=settings.app_name, version=settings.app_version, description="AI-powered legal document drafting API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_url, "http://localhost:8501", "http://127.0.0.1:8501"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"name": settings.app_name, "status": "running", "version": settings.app_version}

@app.get("/health")
def health():
    return {"status": "ok", "ai_configured": bool(settings.gemini_api_key) or settings.use_mock_ai, "model": settings.gemini_model}

app.include_router(router)
