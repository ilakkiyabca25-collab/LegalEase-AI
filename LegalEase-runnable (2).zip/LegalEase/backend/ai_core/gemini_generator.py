from google import genai
from google.genai import types

from backend.config import Settings

class GeminiDocumentGenerator:
    """Generate structured legal-document drafts with Gemini."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = None
        if settings.gemini_api_key:
            self.client = genai.Client(api_key=settings.gemini_api_key)

    @property
    def available(self) -> bool:
        return self.client is not None

    def build_prompt(self, document_type: str, parties: str, terms: str, effective_date: str) -> str:
        return f"""Create a professional legal-document DRAFT from the information below.

Document type: {document_type}
Parties: {parties}
Effective date: {effective_date}
Terms and conditions: {terms}

Requirements:
- Use clear, formal language and practical section headings.
- Do not invent names, dates, money amounts, addresses, laws, jurisdictions, or facts.
- If important information is missing, use [TO BE COMPLETED] rather than guessing.
- Include a title, parties, effective date, recitals/purpose where appropriate, definitions if useful,
  obligations, payment/term provisions when relevant, confidentiality or termination only when relevant,
  governing-law placeholder when not supplied, notices/signatures, and a short document note.
- Preserve the supplied terms accurately.
- Produce plain text suitable for DOCX/PDF conversion. Do not use Markdown tables or code fences.
- This is a drafting aid, not a substitute for review by a qualified lawyer.
"""

    def generate_document(self, document_type: str, parties: str, terms: str, effective_date: str) -> str:
        if not self.client:
            raise RuntimeError("Gemini API is not configured. Add GEMINI_API_KEY to .env or enable USE_MOCK_AI=true.")
        prompt = self.build_prompt(document_type, parties, terms, effective_date)
        response = self.client.models.generate_content(
            model=self.settings.gemini_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=self.settings.temperature,
                max_output_tokens=self.settings.max_output_tokens,
                system_instruction=(
                    "You are LegalEase, an AI legal-document drafting assistant. "
                    "Draft cautiously, never fabricate missing facts, and clearly label output as a draft."
                ),
            ),
        )
        text = (response.text or "").strip()
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return text

    def mock_document(self, document_type: str, parties: str, terms: str, effective_date: str) -> str:
        term_lines = [t.strip() for t in terms.replace("\n", ";").split(";") if t.strip()]
        bullets = "\n".join(f"{i}. {term}" for i, term in enumerate(term_lines, 1)) or "1. [TO BE COMPLETED]"
        return f"""{document_type.upper()} — DRAFT

1. PARTIES
{parties}

2. EFFECTIVE DATE
{effective_date}

3. PURPOSE
This draft records the principal terms supplied by the user for the proposed {document_type}.

4. TERMS AND CONDITIONS
{bullets}

5. ADDITIONAL PROVISIONS
Any provision not supplied in the input should be completed after appropriate legal review.

6. SIGNATURES
Party 1: ______________________________    Date: ______________
Party 2: ______________________________    Date: ______________

DRAFTING NOTICE
This AI-generated document is a drafting aid and should be reviewed by a qualified legal professional before use."""
