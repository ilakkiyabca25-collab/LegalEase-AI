from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "LegalEase"
    app_version: str = "1.0.0"
    environment: str = "development"
    api_host: str = "127.0.0.1"
    api_port: int = 8000
    frontend_url: str = "http://localhost:8501"
    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.5-flash"
    use_mock_ai: bool = False
    max_input_chars: int = 20000
    max_output_tokens: int = 8000
    temperature: float = 0.25
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

@lru_cache
def get_settings() -> Settings:
    return Settings()
