import io
import re
from html import escape
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from fpdf import FPDF


def sanitize_text(text: str) -> str:
    replacements = {"“": '"', "”": '"', "‘": "'", "’": "'", "–": "-", "—": "-", "•": "-", "\u00a0": " "}
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.strip()


def _lines(text: str):
    return [line.strip() for line in sanitize_text(text).splitlines()]


def format_txt(text: str) -> bytes:
    return sanitize_text(text).encode("utf-8")


def format_docx(text: str, doc_type: str, branding_name: str = "LegalEase", logo_path: str | None = None) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)

    styles = doc.styles
    styles["Normal"].font.name = "Times New Roman"
    styles["Normal"].font.size = Pt(11)

    if logo_path and Path(logo_path).exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(logo_path, width=Inches(1.2))

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(doc_type.upper())
    run.bold = True
    run.font.name = "Times New Roman"
    run.font.size = Pt(16)

    brand = doc.add_paragraph()
    brand.alignment = WD_ALIGN_PARAGRAPH.CENTER
    brand.add_run(branding_name).italic = True

    for line in _lines(text):
        if not line:
            doc.add_paragraph()
            continue
        if re.match(r"^(\d+\.|[A-Z][A-Z\s&-]{3,})$", line):
            p = doc.add_paragraph()
            r = p.add_run(line)
            r.bold = True
        else:
            doc.add_paragraph(line)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run(f"{branding_name} | AI-generated draft | Review before use").font.size = Pt(8)

    output = io.BytesIO()
    doc.save(output)
    return output.getvalue()


class _LegalPDF(FPDF):
    def __init__(self, branding_name: str):
        super().__init__()
        self.branding_name = branding_name

    def header(self):
        self.set_font("Helvetica", "B", 9)
        self.cell(0, 7, self.branding_name, 0, 1, "C")
        self.ln(2)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 7)
        self.cell(0, 8, f"{self.branding_name} | AI-generated draft | Page {self.page_no()}", 0, 0, "C")


def format_pdf(text: str, doc_type: str, branding_name: str = "LegalEase") -> bytes:
    pdf = _LegalPDF(branding_name)
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_page()
    pdf.set_title(doc_type)
    pdf.set_font("Helvetica", "B", 16)
    pdf.multi_cell(0, 10, sanitize_text(doc_type.upper()), align="C")
    pdf.ln(4)
    pdf.set_font("Helvetica", "", 10)
    for line in _lines(text):
        if not line:
            pdf.ln(4)
            continue
        if re.match(r"^(\d+\.|[A-Z][A-Z\s&-]{3,})$", line):
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(0, 7, line)
            pdf.set_font("Helvetica", "", 10)
        else:
            pdf.multi_cell(0, 6, line)
    return bytes(pdf.output())


def format_html_preview(text: str) -> str:
    parts = []
    for line in _lines(text):
        if not line:
            parts.append("<div class='spacer'></div>")
        elif re.match(r"^(\d+\.|[A-Z][A-Z\s&-]{3,})$", line):
            parts.append(f"<h3>{escape(line)}</h3>")
        else:
            parts.append(f"<p>{escape(line)}</p>")
    return "".join(parts)
