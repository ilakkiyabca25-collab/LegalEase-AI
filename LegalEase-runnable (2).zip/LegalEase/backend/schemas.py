from pydantic import BaseModel, Field, field_validator

class DocumentRequest(BaseModel):
    document_type: str = Field(..., min_length=2, max_length=120)
    parties: str = Field(..., min_length=2, max_length=5000)
    terms: str = Field(..., min_length=2, max_length=10000)
    effective_date: str = Field(..., min_length=2, max_length=100)
    branding_name: str = Field(default="LegalEase", max_length=100)

    @field_validator("document_type", "parties", "terms", "effective_date", "branding_name")
    @classmethod
    def clean(cls, value: str) -> str:
        return " ".join(value.strip().split()) if "\n" not in value else value.strip()

class DocumentResponse(BaseModel):
    document_type: str
    content: str
    model: str
    mock: bool = False
