import os
os.environ["USE_MOCK_AI"] = "true"

from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_generate_mock():
    response = client.post("/generate", json={
        "document_type": "NDA",
        "parties": "Alice (Disclosing Party), Bob (Receiving Party)",
        "terms": "Confidentiality for 2 years; No disclosure to third parties",
        "effective_date": "2026-09-25",
        "branding_name": "LegalEase",
    })
    assert response.status_code == 200
    assert "NDA" in response.json()["content"]
