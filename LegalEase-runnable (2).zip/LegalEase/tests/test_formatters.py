from backend.services.formatters import format_docx, format_pdf, format_txt, sanitize_text

def test_sanitize_text():
    assert sanitize_text("Hello — “world”") == 'Hello - "world"'

def test_txt_export():
    assert format_txt("Hello").decode("utf-8") == "Hello"

def test_docx_export():
    data = format_docx("TEST DOCUMENT\n\n1. PARTIES\nAlice and Bob", "Agreement")
    assert data[:2] == b"PK"

def test_pdf_export():
    data = format_pdf("TEST DOCUMENT\n\n1. PARTIES\nAlice and Bob", "Agreement")
    assert data.startswith(b"%PDF")
