@echo off
cd /d "%~dp0"
echo ==== LegalEase starting ====

set "PYCMD="
py -3.12 --version >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3.12"
if not defined PYCMD (
    py -3.13 --version >nul 2>&1
    if not errorlevel 1 set "PYCMD=py -3.13"
)
if not defined PYCMD (
    py -3.11 --version >nul 2>&1
    if not errorlevel 1 set "PYCMD=py -3.11"
)
if not defined PYCMD (
    py --version >nul 2>&1
    if not errorlevel 1 set "PYCMD=py"
)
if not defined PYCMD (
    python --version >nul 2>&1
    if not errorlevel 1 set "PYCMD=python"
)
if not defined PYCMD (
    echo Python install aagala. python.org-la irundhu Python 3.12 install pannunga ^(Add to PATH tick pannunga^).
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    %PYCMD% -m venv .venv
)

".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo Install fail aachu. Mela irukura error-ah copy panni anupunga.
    pause
    exit /b 1
)

echo.
echo Open: http://localhost:8501
".venv\Scripts\python.exe" run.py
pause
