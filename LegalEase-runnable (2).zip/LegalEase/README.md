# LegalEase — AI-Powered Legal Document Generator

LegalEase is a local full-stack application based on the supplied project specification. It uses Streamlit for the frontend, FastAPI for the backend, Gemini for AI drafting, and Python document formatters for TXT/DOCX/PDF exports.

## Project structure

```text
LegalEase/
├── backend/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── schemas.py
│   ├── routes.py
│   ├── ai_core/
│   │   ├── __init__.py
│   │   └── gemini_generator.py
│   └── services/
│       ├── __init__.py
│       └── formatters.py
├── frontend/
│   └── app.py
├── tests/
│   ├── test_api.py
│   └── test_formatters.py
├── assets/
├── docs/
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 1. Install Python

Use Python 3.10 or newer.

## 2. Open the project in VS Code

Open the `LegalEase` folder.

## 3. Create a virtual environment

### Windows PowerShell

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### Windows CMD

```cmd
py -m venv .venv
.venv\Scripts\activate
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 4. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 5. Configure Gemini

Copy `.env.example` to `.env` and put your Gemini API key in `GEMINI_API_KEY`.

For a no-key local UI/API test, set:

```env
USE_MOCK_AI=true
```

The default model is configurable through `GEMINI_MODEL`.

## 6. Start the backend

From the project root:

```bash
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Test in a browser:

- http://127.0.0.1:8000/
- http://127.0.0.1:8000/health
- http://127.0.0.1:8000/docs

## 7. Start the frontend

Open a second VS Code terminal, activate the same virtual environment, then run:

```bash
streamlit run frontend/app.py
```

Open the Streamlit URL shown in the terminal, normally http://localhost:8501.

## 8. Test everything

With `USE_MOCK_AI=true`, you can test without making a Gemini request:

```bash
pytest -q
```

Then create a sample document in the UI. Test:

1. Document type
2. Parties
3. Effective date
4. Semicolon-separated terms
5. Generate
6. Edit Document
7. TXT download
8. DOCX download
9. PDF download

Finally set `USE_MOCK_AI=false`, add a valid `GEMINI_API_KEY`, restart the backend, and test the real Gemini generation path.

## Architecture

```text
Streamlit UI
     |
     | POST /generate
     v
FastAPI backend
     |
     v
GeminiDocumentGenerator
     |
     v
Gemini API
     |
     v
Generated draft
     |
     +--> Editable preview
     +--> TXT
     +--> DOCX
     +--> PDF
```

## Notes

- The original specification selects Gemini 1.5 Pro. This implementation keeps the model configurable because Gemini model availability changes over time; the `.env.example` uses a current configurable model default.
- The application does not claim that an AI draft is legal advice. Users should have important documents reviewed by a qualified legal professional.
- No API key is placed in frontend code. It is read by the backend from `.env`.

## Quick start (easiest)

- Windows: double-click `start_windows.bat`
- macOS/Linux: `./start_mac_linux.sh`

It creates the venv, installs everything and starts both servers (`python run.py`). `.env` ships with `USE_MOCK_AI=true`, so it works without an API key.
