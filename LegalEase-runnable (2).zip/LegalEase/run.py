"""Starts the FastAPI backend and the Streamlit frontend together.
Usage:  python run.py      (Ctrl+C to stop both)
"""
import subprocess
import sys
import time

procs = [
    subprocess.Popen([sys.executable, "-m", "uvicorn", "backend.main:app", "--host", "127.0.0.1", "--port", "8000"]),
    subprocess.Popen([sys.executable, "-m", "streamlit", "run", "frontend/app.py", "--server.port", "8501"]),
]
print("\nBackend : http://127.0.0.1:8000/docs\nFrontend: http://localhost:8501\n(Ctrl+C to stop)\n")
try:
    while all(p.poll() is None for p in procs):
        time.sleep(1)
except KeyboardInterrupt:
    pass
finally:
    for p in procs:
        if p.poll() is None:
            p.terminate()
